import React, {Component} from 'react';

class ExpirationPanel extends Component {
    render() {
        return (
            <div>
                <h2>Expires, Please try login again</h2>
            </div>
        );
    }
}

export default ExpirationPanel;